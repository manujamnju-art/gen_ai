"""
🏛️ Government Scheme Finder
AI-powered tool to match Indian citizens with eligible government schemes.

Run: streamlit run app.py
"""

import streamlit as st
import json
import os
import sys

# Add project root to path
sys.path.insert(0, os.path.dirname(__file__))

from src.rag_engine import generate_recommendations
from src.embeddings import get_or_create_collection, load_schemes, get_scheme_by_id

# ───────────────────────────────────────────────────────────
# Page Configuration
# ───────────────────────────────────────────────────────────
st.set_page_config(
    page_title="Government Scheme Finder",
    page_icon="🏛️",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ───────────────────────────────────────────────────────────
# Custom CSS for better UI
# ───────────────────────────────────────────────────────────
st.markdown("""
<style>
    /* Main header */
    .main-header {
        background: linear-gradient(135deg, #FF9933, #FFFFFF, #138808);
        padding: 20px;
        border-radius: 12px;
        text-align: center;
        margin-bottom: 24px;
    }
    .main-header h1 {
        color: #1a1a2e;
        font-size: 2.2rem;
        margin: 0;
    }
    .main-header p {
        color: #333;
        font-size: 1.1rem;
        margin: 5px 0 0 0;
    }

    /* Sidebar styling */
    [data-testid="stSidebar"] {
        background-color: #f8f9fa;
    }

    /* Stats cards */
    .stat-card {
        background: #f0f4ff;
        border-radius: 10px;
        padding: 15px;
        text-align: center;
        border: 1px solid #d0d9ff;
    }
    .stat-card h3 {
        color: #2196F3;
        margin: 0;
        font-size: 2rem;
    }
    .stat-card p {
        color: #555;
        margin: 5px 0 0 0;
        font-size: 0.9rem;
    }

    /* Button styling */
    .stButton > button {
        width: 100%;
        background: linear-gradient(90deg, #FF9933, #e67e00);
        color: white;
        font-weight: bold;
        font-size: 1.1rem;
        border: none;
        border-radius: 8px;
        padding: 12px 20px;
    }
    .stButton > button:hover {
        background: linear-gradient(90deg, #e67e00, #cc6600);
        color: white;
    }

    /* Results section */
    .results-header {
        background: #e8f5e9;
        padding: 15px;
        border-radius: 10px;
        border-left: 5px solid #4CAF50;
        margin: 10px 0;
    }

    /* Footer */
    .footer {
        text-align: center;
        color: #888;
        padding: 20px;
        font-size: 0.85rem;
    }
</style>
""", unsafe_allow_html=True)


# ───────────────────────────────────────────────────────────
# Constants
# ───────────────────────────────────────────────────────────
INDIAN_STATES = [
    "Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar",
    "Chhattisgarh", "Goa", "Gujarat", "Haryana", "Himachal Pradesh",
    "Jharkhand", "Karnataka", "Kerala", "Madhya Pradesh", "Maharashtra",
    "Manipur", "Meghalaya", "Mizoram", "Nagaland", "Odisha", "Punjab",
    "Rajasthan", "Sikkim", "Tamil Nadu", "Telangana", "Tripura",
    "Uttar Pradesh", "Uttarakhand", "West Bengal",
    "Delhi", "Chandigarh", "Jammu & Kashmir", "Ladakh",
    "Puducherry", "Andaman & Nicobar Islands", "Lakshadweep",
    "Dadra & Nagar Haveli and Daman & Diu"
]

OCCUPATIONS = [
    "Student", "Farmer", "Self-Employed / Business Owner",
    "Entrepreneur / Startup Founder", "Salaried Employee",
    "Daily Wage Worker", "Street Vendor / Hawker",
    "Artisan / Craftsperson", "Homemaker", "Retired / Senior Citizen",
    "Unemployed", "Fisherman", "Armed Forces Aspirant", "Other"
]

INTEREST_AREAS = [
    "💰 Financial Assistance / Loans",
    "🏥 Health & Medical Insurance",
    "🏠 Housing",
    "🎓 Education & Scholarships",
    "👩 Women Empowerment",
    "🌾 Agriculture & Farming",
    "🏭 Entrepreneurship & Business",
    "💼 Employment & Jobs",
    "🛠️ Skill Development & Training",
    "🛡️ Insurance & Pension",
    "🍚 Food Security",
    "👶 Child Welfare",
]

CATEGORY_EMOJI = {
    "agriculture": "🌾",
    "health": "🏥",
    "housing": "🏠",
    "finance": "💰",
    "education": "🎓",
    "women_and_child": "👩",
    "entrepreneurship": "🚀",
    "employment": "💼",
    "skill_development": "🛠️",
    "insurance": "🛡️",
    "defence": "🎖️",
    "food_security": "🍚",
    "digital": "💻",
}


# ───────────────────────────────────────────────────────────
# Helper Functions
# ───────────────────────────────────────────────────────────
def check_db_ready():
    """Check if ChromaDB has been populated."""
    try:
        collection = get_or_create_collection()
        return collection.count() > 0
    except Exception:
        return False


def get_scheme_stats():
    """Get statistics about loaded schemes."""
    try:
        schemes = load_schemes()
        categories = {}
        for s in schemes:
            cat = s.get("category", "other")
            categories[cat] = categories.get(cat, 0) + 1
        return len(schemes), categories
    except Exception:
        return 0, {}


# ───────────────────────────────────────────────────────────
# Main App
# ───────────────────────────────────────────────────────────
def main():
    # ── Header ──
    st.markdown("""
    <div class="main-header">
        <h1>🏛️ Government Scheme Finder</h1>
        <p>AI-powered tool to find government schemes you're eligible for</p>
    </div>
    """, unsafe_allow_html=True)

    # ── Check if database is ready ──
    db_ready = check_db_ready()

    if not db_ready:
        st.error("""
        ⚠️ **Database not initialized!**

        Please run the setup script first:
        ```bash
        python setup_db.py
        ```
        This will load all government schemes into the vector database.
        """)
        st.stop()

    # ── Stats Row ──
    total_schemes, categories = get_scheme_stats()
    col1, col2, col3, col4 = st.columns(4)

    with col1:
        st.markdown(f"""
        <div class="stat-card">
            <h3>{total_schemes}</h3>
            <p>Total Schemes</p>
        </div>
        """, unsafe_allow_html=True)

    with col2:
        st.markdown(f"""
        <div class="stat-card">
            <h3>{len(categories)}</h3>
            <p>Categories</p>
        </div>
        """, unsafe_allow_html=True)

    with col3:
        st.markdown(f"""
        <div class="stat-card">
            <h3>🤖</h3>
            <p>AI-Powered Matching</p>
        </div>
        """, unsafe_allow_html=True)

    with col4:
        st.markdown(f"""
        <div class="stat-card">
            <h3>📋</h3>
            <p>Step-by-Step Guide</p>
        </div>
        """, unsafe_allow_html=True)

    st.markdown("---")

    # ── Sidebar: User Profile Form ──
    with st.sidebar:
        st.markdown("## 👤 Your Profile")
        st.markdown("Fill in your details to find matching schemes:")
        st.markdown("---")

        # Name
        name = st.text_input("📛 Your Name", placeholder="Enter your name")

        # Age
        age = st.number_input("🎂 Age", min_value=0, max_value=120, value=25, step=1)

        # Gender
        gender = st.selectbox("⚧ Gender", ["Male", "Female", "Other", "Prefer not to say"])

        # State
        state = st.selectbox("📍 State / UT", INDIAN_STATES)

        # Annual Income
        income = st.number_input(
            "💵 Annual Family Income (₹)",
            min_value=0,
            max_value=10000000,
            value=300000,
            step=50000,
            help="Enter your total annual family income in Rupees"
        )

        # Occupation
        occupation = st.selectbox("💼 Occupation", OCCUPATIONS)

        # Caste Category
        caste_category = st.selectbox(
            "📋 Category",
            ["General", "OBC", "SC", "ST", "Minority"],
            help="Select your caste/reservation category"
        )

        st.markdown("---")

        # Areas of Interest
        st.markdown("### 🎯 Areas of Interest")
        interests = st.multiselect(
            "Select areas you're interested in:",
            INTEREST_AREAS,
            default=[],
            help="Select one or more areas to get more relevant results"
        )

        st.markdown("---")

        # Submit Button
        find_schemes = st.button("🔍 Find My Schemes", type="primary")

    # ── Main Content Area ──
    if find_schemes:
        if not name:
            st.warning("Please enter your name in the sidebar.")
            st.stop()

        # Build user profile
        user_profile = {
            "name": name,
            "age": age,
            "gender": gender.lower() if gender != "Prefer not to say" else "all",
            "state": state,
            "annual_income": income,
            "occupation": occupation.lower().split("/")[0].strip(),
            "caste_category": caste_category.lower(),
            "interests": [i.split(" ", 1)[1] if " " in i else i for i in interests],
        }

        # Show user profile summary
        st.markdown(f"""
        <div class="results-header">
            <strong>🔍 Searching schemes for:</strong> {name} | Age: {age} | {gender} | {state} | 
            Income: ₹{income:,} | {occupation} | {caste_category}
        </div>
        """, unsafe_allow_html=True)

        # Generate recommendations
        with st.spinner("🤖 AI is analyzing your profile and finding matching schemes..."):
            recommendations, matched_ids = generate_recommendations(user_profile)

        # Display results
        if recommendations:
            st.markdown("## 📋 Your Personalized Scheme Recommendations")
            st.markdown("---")
            st.markdown(recommendations)

            # Show detailed scheme cards for matched schemes
            if matched_ids:
                st.markdown("---")
                st.markdown("## 📚 Detailed Scheme Information")

                for scheme_id in matched_ids[:10]:
                    scheme = get_scheme_by_id(scheme_id)
                    if scheme:
                        emoji = CATEGORY_EMOJI.get(scheme.get("category", ""), "📌")
                        with st.expander(f"{emoji} {scheme['name']}", expanded=False):
                            col_a, col_b = st.columns([2, 1])

                            with col_a:
                                st.markdown(f"**📝 Description:** {scheme['description']}")
                                st.markdown(f"**💰 Benefits:** {scheme['benefits']}")
                                st.markdown(f"**📋 How to Apply:**\n{scheme['how_to_apply']}")

                            with col_b:
                                st.markdown("**📄 Documents Required:**")
                                for doc in scheme.get("documents_required", []):
                                    st.markdown(f"  - ✅ {doc}")

                                st.markdown(f"**🔗 Official Website:**")
                                st.markdown(f"[{scheme.get('official_website', '#')}]({scheme.get('official_website', '#')})")

                                age_min = scheme["eligibility"].get("age_min", 0)
                                age_max = scheme["eligibility"].get("age_max", 100)
                                st.markdown(f"**👥 Age:** {age_min} - {age_max} years")

                                max_inc = scheme["eligibility"].get("max_income", 0)
                                if max_inc > 0:
                                    st.markdown(f"**💵 Max Income:** ₹{max_inc:,}")
                                else:
                                    st.markdown("**💵 Income:** No limit")

        st.markdown("---")
        st.info("💡 **Tip:** The information above is AI-generated. Always verify details on the official scheme websites before applying.")

    else:
        # Landing page content
        st.markdown("## 🎯 How It Works")

        col1, col2, col3 = st.columns(3)

        with col1:
            st.markdown("""
            ### Step 1: Fill Your Profile
            Enter your basic details like age, income, 
            occupation, and state in the sidebar form.
            """)

        with col2:
            st.markdown("""
            ### Step 2: AI Matches Schemes
            Our AI analyzes your profile against 28+ 
            government schemes to find your best matches.
            """)

        with col3:
            st.markdown("""
            ### Step 3: Get Recommendations
            Receive personalized scheme recommendations 
            with benefits, eligibility, and how to apply.
            """)

        st.markdown("---")

        # Show all available schemes
        st.markdown("## 📊 Available Schemes by Category")

        schemes = load_schemes()
        cat_schemes = {}
        for s in schemes:
            cat = s.get("category", "other")
            if cat not in cat_schemes:
                cat_schemes[cat] = []
            cat_schemes[cat].append(s)

        cols = st.columns(3)
        for i, (cat, scheme_list) in enumerate(sorted(cat_schemes.items())):
            emoji = CATEGORY_EMOJI.get(cat, "📌")
            with cols[i % 3]:
                st.markdown(f"### {emoji} {cat.replace('_', ' ').title()}")
                for s in scheme_list:
                    st.markdown(f"- {s['name']}")

    # Footer
    st.markdown("""
    <div class="footer">
        <p>🏛️ Government Scheme Finder | Built with Streamlit + Gemini AI + ChromaDB</p>
        <p>⚠️ Disclaimer: This is an AI-powered tool for informational purposes only. 
        Always verify scheme details on official government websites.</p>
    </div>
    """, unsafe_allow_html=True)


if __name__ == "__main__":
    main()
