# 🏛️ Government Scheme Finder

An **AI-powered web application** that matches Indian citizens with eligible government schemes based on their profile — age, income, gender, state, occupation, and category. Built using **RAG (Retrieval-Augmented Generation)** with Gemini AI.

![Python](https://img.shields.io/badge/Python-3.10+-blue?logo=python)
![Streamlit](https://img.shields.io/badge/Streamlit-1.40-red?logo=streamlit)
![Gemini](https://img.shields.io/badge/Gemini_AI-1.5_Flash-blue?logo=google)
![ChromaDB](https://img.shields.io/badge/ChromaDB-Vector_Store-purple)

## ✨ Features

- 🔍 **Smart Matching** — AI matches your profile with 28+ government schemes
- 🧠 **RAG-Powered** — Answers grounded in actual scheme data, not hallucinated
- 📋 **Step-by-Step Guide** — How to apply, documents needed, official links
- 🎯 **Personalized** — Results tailored to your age, income, occupation & more
- 🆓 **Free to Use** — Uses free Gemini API and local embeddings

## 🛠️ Tech Stack

| Component | Technology |
|-----------|-----------|
| Frontend | Streamlit |
| LLM | Google Gemini 1.5 Flash |
| Embeddings | Sentence-Transformers (all-MiniLM-L6-v2) |
| Vector DB | ChromaDB |
| Language | Python 3.10+ |

## 📁 Project Structure

```
government-scheme-finder/
├── app.py                  # Streamlit web application
├── setup_db.py             # Database setup script (run once)
├── requirements.txt        # Python dependencies
├── .env.example            # Environment variable template
├── README.md               # This file
├── data/
│   └── schemes.json        # 28+ government schemes database
├── src/
│   ├── __init__.py
│   ├── embeddings.py       # ChromaDB & embedding logic
│   └── rag_engine.py       # RAG pipeline with Gemini
└── chroma_db/              # Auto-generated vector store
```

## 🚀 Quick Start

### 1. Clone & Install

```bash
cd government-scheme-finder

# Create virtual environment (recommended)
python -m venv venv
venv\Scripts\activate        # Windows
# source venv/bin/activate   # Mac/Linux

# Install dependencies
pip install -r requirements.txt
```

### 2. Set Up API Key

Get a **free** Gemini API key from [Google AI Studio](https://aistudio.google.com/apikey).

```bash
# Create .env file
copy .env.example .env      # Windows
# cp .env.example .env      # Mac/Linux

# Edit .env and add your key
# GOOGLE_API_KEY=your_key_here
```

### 3. Initialize Database

```bash
python setup_db.py
```

This downloads the embedding model (~80MB, one-time) and indexes all 28 schemes into ChromaDB.

### 4. Run the App

```bash
streamlit run app.py
```

The app opens at `http://localhost:8501` 🎉

## 📸 How to Use

1. **Fill your profile** in the sidebar (name, age, gender, state, income, occupation, category)
2. **Select areas of interest** (health, education, finance, etc.)
3. **Click "Find My Schemes"**
4. **Get personalized recommendations** with benefits, eligibility, and how to apply

## 📊 Covered Schemes (28+)

| Category | Schemes |
|----------|---------|
| 🌾 Agriculture | PM Kisan, Fasal Bima, Kisan Credit Card |
| 🏥 Health | Ayushman Bharat (PM-JAY) |
| 🏠 Housing | PM Awas Yojana (Urban & Rural) |
| 💰 Finance | MUDRA, Jan Dhan, PM SVANidhi |
| 🎓 Education | National Scholarship Portal, Digital India Internship |
| 👩 Women & Child | Sukanya Samriddhi, Ujjwala, Matru Vandana, Ladli Behna, Free Silai Machine |
| 🚀 Entrepreneurship | Startup India, Stand Up India |
| 🛠️ Skills | PM Vishwakarma, PMKVY, Skill India Digital |
| 🛡️ Insurance | PMJJBY, PMSBY, Atal Pension |
| 💼 Employment | MGNREGA, Agnipath |
| 🍚 Food Security | PM Garib Kalyan Anna Yojana |

## 🏗️ Architecture

```
User Profile → Query Builder → ChromaDB (Semantic Search)
                                     ↓
                              Retrieved Schemes
                                     ↓
                     Gemini LLM (RAG: Context + Profile)
                                     ↓
                      Personalized Recommendations
```

## ⚠️ Disclaimer

This is an AI-powered tool for **informational purposes only**. Always verify scheme details on official government websites before applying. The AI may occasionally provide inaccurate information.

## 📄 License

MIT License — free to use, modify, and distribute.
