"""
RAG Engine Module
Handles the Retrieval-Augmented Generation pipeline using Gemini LLM.
"""

import os
from dotenv import load_dotenv
import google.generativeai as genai
from src.embeddings import search_schemes, get_scheme_by_id

# Load environment variables
load_dotenv()

# Configure Gemini
GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")
if GOOGLE_API_KEY:
    genai.configure(api_key=GOOGLE_API_KEY)


def build_user_query(user_profile):
    """
    Converts user profile into a natural language query
    for semantic search in ChromaDB.
    """
    parts = []

    # Age context
    age = user_profile.get("age", 0)
    if age > 0:
        if age < 18:
            parts.append(f"schemes for children and minors aged {age}")
        elif age < 25:
            parts.append(f"schemes for young adults and youth aged {age}")
        elif age < 40:
            parts.append(f"schemes for adults aged {age}")
        elif age < 60:
            parts.append(f"schemes for middle-aged adults aged {age}")
        else:
            parts.append(f"schemes for senior citizens aged {age}")

    # Gender context
    gender = user_profile.get("gender", "")
    if gender:
        parts.append(f"for {gender}")

    # Income context
    income = user_profile.get("annual_income", 0)
    if income > 0:
        if income < 200000:
            parts.append(f"for low income families earning Rs {income:,} per year below poverty line BPL")
        elif income < 500000:
            parts.append(f"for lower middle income families earning Rs {income:,} per year")
        elif income < 1000000:
            parts.append(f"for middle income families earning Rs {income:,} per year")
        else:
            parts.append(f"for families with annual income of Rs {income:,}")

    # Occupation context
    occupation = user_profile.get("occupation", "")
    if occupation:
        parts.append(f"for {occupation}")

    # State context
    state = user_profile.get("state", "")
    if state:
        parts.append(f"in {state}")

    # Category context
    category = user_profile.get("caste_category", "")
    if category:
        parts.append(f"for {category} category")

    # Area of interest
    interests = user_profile.get("interests", [])
    if interests:
        parts.append(f"related to {', '.join(interests)}")

    query = " ".join(parts) if parts else "government schemes for citizens of India"
    return query


def build_metadata_filters(user_profile):
    """
    Builds ChromaDB metadata filters based on user profile
    for pre-filtering schemes before semantic search.
    """
    filters = {}

    age = user_profile.get("age", 0)
    gender = user_profile.get("gender", "")

    # Build composite filters using $and
    conditions = []

    if age > 0:
        conditions.append({"age_min": {"$lte": age}})
        conditions.append({"age_max": {"$gte": age}})

    if gender and gender.lower() != "prefer not to say":
        # Include schemes for the specific gender OR "all" genders
        conditions.append({
            "$or": [
                {"gender": {"$eq": gender.lower()}},
                {"gender": {"$eq": "all"}}
            ]
        })

    if len(conditions) > 1:
        filters = {"$and": conditions}
    elif len(conditions) == 1:
        filters = conditions[0]

    return filters if filters else None


def retrieve_relevant_schemes(user_profile, n_results=10):
    """
    Retrieves relevant schemes using semantic search + metadata filtering.
    """
    query = build_user_query(user_profile)
    filters = build_metadata_filters(user_profile)

    # Try with filters first
    try:
        results = search_schemes(query, n_results=n_results, filters=filters)
    except Exception:
        # Fallback without filters if filter query fails
        results = search_schemes(query, n_results=n_results)

    # If too few results, do another search without filters
    if len(results) < 3:
        results = search_schemes(query, n_results=n_results)

    return results


def build_rag_prompt(user_profile, retrieved_schemes):
    """
    Builds the final prompt for the Gemini LLM with user profile
    and retrieved scheme context.
    """
    # Format user profile
    profile_text = f"""
USER PROFILE:
- Name: {user_profile.get('name', 'Citizen')}
- Age: {user_profile.get('age', 'Not specified')}
- Gender: {user_profile.get('gender', 'Not specified')}
- State: {user_profile.get('state', 'Not specified')}
- Annual Income: Rs {user_profile.get('annual_income', 0):,}
- Occupation: {user_profile.get('occupation', 'Not specified')}
- Caste Category: {user_profile.get('caste_category', 'Not specified')}
- Areas of Interest: {', '.join(user_profile.get('interests', ['All']))}
""".strip()

    # Format retrieved schemes as context
    context_parts = []
    for i, result in enumerate(retrieved_schemes, 1):
        context_parts.append(f"--- SCHEME {i} ---\n{result['document']}\nOfficial Website: {result['metadata'].get('official_website', 'N/A')}\n")

    context_text = "\n".join(context_parts)

    # Build the final prompt
    prompt = f"""You are an expert Government Scheme Advisor for Indian citizens. Your job is to analyze the citizen's profile and match them with the most relevant government schemes from the provided context.

{profile_text}

AVAILABLE SCHEMES (Retrieved from database):
{context_text}

INSTRUCTIONS:
1. Carefully analyze the user's profile (age, gender, income, occupation, state, category).
2. From the schemes provided above, select ONLY the schemes where the user is genuinely eligible.
3. Rank the schemes by relevance — most beneficial schemes first.
4. For each matched scheme, provide:
   - ✅ Scheme Name
   - 💰 Key Benefits (in simple language)
   - 📋 Why this person is eligible
   - 📝 How to Apply (simple step-by-step)
   - 📄 Documents Needed
   - 🔗 Official Website
5. If a scheme is NOT relevant to this user, DO NOT include it.
6. Use simple, easy-to-understand language. Avoid jargon.
7. If the user seems eligible for very few schemes, mention that and suggest they check back with updated information.
8. Add a brief note at the end about general tips for applying to government schemes.

Format your response in a clear, well-organized manner using markdown. Use emojis for visual clarity.
Respond in English. Keep explanations concise but helpful.
"""

    return prompt


def generate_recommendations(user_profile):
    """
    Main function: Retrieves relevant schemes and generates
    personalized recommendations using Gemini LLM.

    Returns:
        tuple: (recommendations_text, matched_scheme_ids)
    """
    if not GOOGLE_API_KEY:
        return (
            "⚠️ **API Key Not Found!**\n\n"
            "Please set your Google Gemini API key:\n"
            "1. Get a free key from [Google AI Studio](https://aistudio.google.com/apikey)\n"
            "2. Create a `.env` file in the project root\n"
            "3. Add: `GOOGLE_API_KEY=your_key_here`\n"
            "4. Restart the app",
            []
        )

    # Step 1: Retrieve relevant schemes from vector store
    retrieved_schemes = retrieve_relevant_schemes(user_profile)

    if not retrieved_schemes:
        return (
            "😔 No matching schemes found. Please try with different profile information.",
            []
        )

    # Step 2: Build RAG prompt
    prompt = build_rag_prompt(user_profile, retrieved_schemes)

    # Step 3: Generate response using Gemini
    try:
        model = genai.GenerativeModel("gemini-1.5-flash")
        response = model.generate_content(
            prompt,
            generation_config=genai.GenerationConfig(
                temperature=0.3,  # Lower temperature for factual responses
                max_output_tokens=4096,
            ),
            safety_settings={
                "HARM_CATEGORY_HARASSMENT": "BLOCK_NONE",
                "HARM_CATEGORY_HATE_SPEECH": "BLOCK_NONE",
                "HARM_CATEGORY_SEXUALLY_EXPLICIT": "BLOCK_NONE",
                "HARM_CATEGORY_DANGEROUS_CONTENT": "BLOCK_NONE",
            }
        )

        recommendations = response.text
        matched_ids = [r["metadata"]["scheme_id"] for r in retrieved_schemes]

        return recommendations, matched_ids

    except Exception as e:
        return (
            f"❌ **Error generating recommendations:**\n\n`{str(e)}`\n\n"
            "Please check your API key and internet connection.",
            []
        )
