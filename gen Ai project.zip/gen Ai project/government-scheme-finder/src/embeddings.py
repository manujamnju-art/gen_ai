"""
Embeddings & Vector Store Module
Handles loading schemes, generating embeddings, and ChromaDB operations.
"""

import json
import os
import chromadb
from chromadb.utils import embedding_functions


# Use the free, local sentence-transformer model for embeddings
EMBEDDING_MODEL = "all-MiniLM-L6-v2"
COLLECTION_NAME = "government_schemes"
DB_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), "chroma_db")
DATA_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data", "schemes.json")


def get_embedding_function():
    """Returns the sentence-transformer embedding function."""
    return embedding_functions.SentenceTransformerEmbeddingFunction(
        model_name=EMBEDDING_MODEL
    )


def get_chroma_client():
    """Returns a persistent ChromaDB client."""
    return chromadb.PersistentClient(path=DB_PATH)


def get_or_create_collection():
    """Gets or creates the schemes collection in ChromaDB."""
    client = get_chroma_client()
    ef = get_embedding_function()
    collection = client.get_or_create_collection(
        name=COLLECTION_NAME,
        embedding_function=ef,
        metadata={"description": "Indian Government Schemes for citizen matching"}
    )
    return collection


def load_schemes():
    """Loads schemes from the JSON data file."""
    with open(DATA_PATH, "r", encoding="utf-8") as f:
        schemes = json.load(f)
    return schemes


def build_scheme_document(scheme):
    """
    Converts a scheme dict into a rich text document for embedding.
    Combines name, description, eligibility, benefits, and category
    into a single searchable string.
    """
    eligibility = scheme.get("eligibility", {})

    # Build eligibility text
    gender_text = eligibility.get("gender", "all")
    if gender_text == "all":
        gender_text = "men and women"
    elif gender_text == "female":
        gender_text = "women and girls only"

    occupation_text = ", ".join(eligibility.get("occupation", ["all"]))
    states_text = ", ".join(eligibility.get("states", ["all"]))
    category_text = ", ".join(eligibility.get("caste_category", ["all"]))

    age_min = eligibility.get("age_min", 0)
    age_max = eligibility.get("age_max", 100)

    max_income = eligibility.get("max_income", 0)
    income_text = f"Maximum annual income: Rs {max_income:,}" if max_income > 0 else "No income limit"

    document = f"""
Scheme Name: {scheme['name']}
Category: {scheme.get('category', 'general')}
Description: {scheme['description']}
Benefits: {scheme.get('benefits', 'N/A')}
Eligibility:
  - Age: {age_min} to {age_max} years
  - Gender: {gender_text}
  - {income_text}
  - Occupation: {occupation_text}
  - States: {states_text}
  - Caste/Category: {category_text}
How to Apply: {scheme.get('how_to_apply', 'N/A')}
Documents Required: {', '.join(scheme.get('documents_required', []))}
""".strip()

    return document


def populate_vector_store():
    """
    Loads all schemes from JSON and populates ChromaDB.
    This is idempotent — it clears and re-populates the collection.
    """
    schemes = load_schemes()
    collection = get_or_create_collection()

    # Clear existing data
    existing = collection.get()
    if existing["ids"]:
        collection.delete(ids=existing["ids"])

    # Prepare documents, metadata, and IDs
    documents = []
    metadatas = []
    ids = []

    for scheme in schemes:
        doc = build_scheme_document(scheme)
        documents.append(doc)

        metadata = {
            "scheme_id": scheme["id"],
            "name": scheme["name"],
            "category": scheme.get("category", "general"),
            "age_min": scheme["eligibility"].get("age_min", 0),
            "age_max": scheme["eligibility"].get("age_max", 100),
            "max_income": scheme["eligibility"].get("max_income", 0),
            "gender": scheme["eligibility"].get("gender", "all"),
            "official_website": scheme.get("official_website", ""),
        }
        metadatas.append(metadata)
        ids.append(scheme["id"])

    # Add all documents to ChromaDB
    collection.add(
        documents=documents,
        metadatas=metadatas,
        ids=ids
    )

    print(f"✅ Successfully loaded {len(documents)} schemes into ChromaDB")
    return len(documents)


def search_schemes(query_text, n_results=10, filters=None):
    """
    Searches ChromaDB for schemes matching the query text.

    Args:
        query_text: The semantic search query.
        n_results: Number of results to return.
        filters: Optional ChromaDB where filter dict.

    Returns:
        List of dicts with matched scheme documents and metadata.
    """
    collection = get_or_create_collection()

    search_params = {
        "query_texts": [query_text],
        "n_results": min(n_results, collection.count()),
    }

    if filters:
        search_params["where"] = filters

    results = collection.query(**search_params)

    matched_schemes = []
    if results and results["documents"]:
        for i in range(len(results["documents"][0])):
            matched_schemes.append({
                "document": results["documents"][0][i],
                "metadata": results["metadatas"][0][i],
                "distance": results["distances"][0][i] if results.get("distances") else None,
            })

    return matched_schemes


def get_scheme_by_id(scheme_id):
    """Gets full scheme details from the JSON data by ID."""
    schemes = load_schemes()
    for scheme in schemes:
        if scheme["id"] == scheme_id:
            return scheme
    return None
