"""
Setup Script — Run this once to populate the ChromaDB vector store
with government scheme data.

Usage:
    python setup_db.py
"""

import sys
import os
import io

# Fix Windows console encoding for emoji/unicode characters
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')

# Add project root to path
sys.path.insert(0, os.path.dirname(__file__))

from src.embeddings import populate_vector_store, load_schemes


def main():
    print("=" * 60)
    print("🏛️  Government Scheme Finder — Database Setup")
    print("=" * 60)
    print()

    # Load and display scheme stats
    schemes = load_schemes()
    print(f"📂 Found {len(schemes)} schemes in data/schemes.json")
    print()

    # Show categories
    categories = {}
    for scheme in schemes:
        cat = scheme.get("category", "other")
        categories[cat] = categories.get(cat, 0) + 1

    print("📊 Schemes by Category:")
    for cat, count in sorted(categories.items()):
        print(f"   • {cat.replace('_', ' ').title()}: {count}")
    print()

    # Populate vector store
    print("🔄 Generating embeddings and populating ChromaDB...")
    print("   (This may take a minute on first run as the model downloads)")
    print()

    count = populate_vector_store()

    print()
    print(f"🎉 Database setup complete! {count} schemes indexed.")
    print()
    print("Next steps:")
    print("  1. Create a .env file with your Gemini API key:")
    print("     GOOGLE_API_KEY=your_key_here")
    print()
    print("  2. Run the app:")
    print("     streamlit run app.py")
    print()


if __name__ == "__main__":
    main()
